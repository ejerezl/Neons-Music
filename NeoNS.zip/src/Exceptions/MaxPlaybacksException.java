package Exceptions;

public class MaxPlaybacksException extends Exception {
    public MaxPlaybacksException(){
        super();
    }
}
